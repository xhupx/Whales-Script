import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hits } from '@/lib/db/schema';
import { sql, gte } from 'drizzle-orm';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const timeframe = searchParams.get('timeframe') || 'alltime';
  
  let dateLimit = new Date(0);
  const now = new Date();
  if (timeframe === 'daily') dateLimit = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  else if (timeframe === 'weekly') dateLimit = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  else if (timeframe === 'monthly') dateLimit = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  const leaderboard = await db.select({
    userWebhook: hits.userWebhook,
    hitCount: sql<number>`count(${hits.id})`.mapWith(Number)
  })
  .from(hits)
  .where(gte(hits.createdAt, dateLimit))
  .groupBy(hits.userWebhook)
  .orderBy(sql`count(${hits.id}) DESC`)
  .limit(10);

  return NextResponse.json({ leaderboard });
}