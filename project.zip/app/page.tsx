import { desc, eq } from 'drizzle-orm'
import { getServerSession } from 'next-auth'
import { DiscordLoginCard } from '@/components/discord-login-card'
import { MrScriptsDashboard, type SavedConfiguration } from '@/components/mr-scripts-dashboard'
import { authOptions } from '@/lib/auth-options'
import { db } from '@/lib/db'
import { configs } from '@/lib/db/schema'

export const dynamic = 'force-dynamic'

export default async function Page() {
  const session = await getServerSession(authOptions)
  const userId = session?.user?.id

  if (!userId || !session?.user) return <DiscordLoginCard />

  let initialConfigs: SavedConfiguration[] = []
  let initialLoadError = ''

  try {
    const records = await db
      .select()
      .from(configs)
      .where(eq(configs.userId, userId))
      .orderBy(desc(configs.createdAt))

    initialConfigs = records.map((config) => ({
      id: config.id,
      name: config.name,
      game: config.game as any,
      webhook: config.webhook,
      usernames: config.usernames,
      minRarity: config.minRarity,
      minUSD: config.minUSD || '5',
      pingEveryone: config.pingEveryone,
      createdAt: config.createdAt.toISOString(),
      token: config.token,
      pastefyId: config.pastefyId // ✅ ضفنا دي عشان الريفريش
    }))
  } catch (error) {
    initialLoadError = 'Saved templates could not be loaded.'
  }

  return (
    <MrScriptsDashboard
      user={{ id: userId, name: session.user.name, image: session.user.image }}
      initialConfigs={initialConfigs}
      initialLoadError={initialLoadError}
    />
  )
}