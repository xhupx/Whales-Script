-- Apply this once to the connected Neon database before using the API.
-- The token column stores a SHA-256 digest; only the plaintext token returned
-- once by POST /api/config can be used to retrieve a configuration.
CREATE TABLE IF NOT EXISTS public.configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "userId" text NOT NULL DEFAULT 'anonymous',
  "discordId" text,
  name text NOT NULL DEFAULT 'Untitled script',
  webhook text NOT NULL,
  usernames text[] NOT NULL,
  "minRarity" text NOT NULL CHECK ("minRarity" IN ('Mythical', 'Legendary', 'Rare', 'Uncommon', 'Common')),
  "pingEveryone" boolean NOT NULL,
  token text NOT NULL UNIQUE,
  "createdAt" timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.configs
  ADD COLUMN IF NOT EXISTS name text NOT NULL DEFAULT 'Untitled script';

-- New application data is stored as private, non-executable text templates.
-- The legacy configs table is retained unchanged so existing rows are not deleted.
CREATE TABLE IF NOT EXISTS public.safe_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "userId" text NOT NULL,
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 80),
  game text NOT NULL CHECK (char_length(game) BETWEEN 1 AND 80),
  content text NOT NULL CHECK (char_length(content) <= 12000),
  "createdAt" timestamp with time zone NOT NULL DEFAULT now(),
  "updatedAt" timestamp with time zone NOT NULL DEFAULT now()
);
