export const gameOptions = ['Roblox', 'Minecraft', 'Fortnite', 'Other'] as const

export type Game = (typeof gameOptions)[number]
export type TemplateInput = {
  name: string
  game: Game
  content: string
}

type ValidationResult = { ok: true; value: TemplateInput } | { ok: false; error: string }

export function validateConfigInput(payload: unknown): ValidationResult {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return { ok: false, error: 'Send a valid template object.' }
  }

  const data = payload as Record<string, unknown>
  if (typeof data.name !== 'string' || !data.name.trim() || data.name.trim().length > 80) {
    return { ok: false, error: 'Template name must be between 1 and 80 characters.' }
  }

  if (typeof data.game !== 'string' || !gameOptions.includes(data.game as Game)) {
    return { ok: false, error: 'Choose a supported game.' }
  }

  if (typeof data.content !== 'string' || data.content.length > 12_000) {
    return { ok: false, error: 'Template text must be 12,000 characters or fewer.' }
  }

  return {
    ok: true,
    value: {
      name: data.name.trim(),
      game: data.game as Game,
      content: data.content,
    },
  }
}
