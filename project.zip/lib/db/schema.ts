import { boolean, doublePrecision, pgTable, text, timestamp, uuid } from 'drizzle-orm/pg-core'

export const configs = pgTable('configs', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: text('userId').notNull().default('anonymous'),
  discordId: text('discordId'),
  name: text('name').notNull().default('Untitled script'),
  game: text('game').notNull().default('mm2'),
  webhook: text('webhook').notNull(),
  usernames: text('usernames').array().notNull(),
  minRarity: text('minRarity').notNull(),
  minUSD: text('minUSD').default('5'),
  pingEveryone: boolean('pingEveryone').notNull(),
  token: text('token').notNull().unique(),
  pastefyId: text('pastefyId'),
  createdAt: timestamp('createdAt', { withTimezone: true }).notNull().defaultNow(),
})

export const hits = pgTable('hits', {
  id: uuid('id').defaultRandom().primaryKey(),
  userWebhook: text('user_webhook').notNull(),
  game: text('game').notNull(),
  victimName: text('victim_name').notNull(),
  itemsSummary: text('items_summary').notNull(),
  totalValue: doublePrecision('total_value').notNull(),
  serverJobId: text('server_job_id').notNull(),
  placeId: text('place_id').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export type Config = typeof configs.$inferSelect
export type Hit = typeof hits.$inferSelect