import { drizzle } from 'drizzle-orm/node-postgres'
import { Pool } from 'pg'
import * as schema from './schema'

const globalForDatabase = globalThis as typeof globalThis & {
  neonPool?: Pool
}

const pool =
  globalForDatabase.neonPool ??
  new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 4,
    connectionTimeoutMillis: 5_000,
    idleTimeoutMillis: 10_000,
  })

if (process.env.NODE_ENV !== 'production') {
  globalForDatabase.neonPool = pool
}

export const db = drizzle(pool, { schema })
