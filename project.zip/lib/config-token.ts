import { createHash, randomBytes } from 'node:crypto'

const TOKEN_PATTERN = /^sec_tok_[a-f0-9]{64}$/

export function createConfigToken() {
  return `sec_tok_${randomBytes(32).toString('hex')}`
}

export function hashConfigToken(token: string) {
  return createHash('sha256').update(token).digest('hex')
}

export function isConfigToken(token: string) {
  return TOKEN_PATTERN.test(token)
}
