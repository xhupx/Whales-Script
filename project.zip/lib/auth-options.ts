import type { NextAuthOptions } from 'next-auth'
import DiscordProvider from 'next-auth/providers/discord'

export const authOptions: NextAuthOptions = {
  providers: [
    DiscordProvider({
      clientId: process.env.DISCORD_CLIENT_ID ?? '',
      clientSecret: process.env.DISCORD_CLIENT_SECRET ?? '',
      // NextAuth v4's OpenID client requires an issuer even for OAuth-only providers.
      issuer: 'https://discord.com',
      authorization: { params: { scope: 'identify' } },
      profile(profile) {
        const discordProfile = profile as typeof profile & {
          global_name?: string | null
        }
        const avatar = discordProfile.avatar
        const image = avatar
          ? `https://cdn.discordapp.com/avatars/${discordProfile.id}/${avatar}.${avatar.startsWith('a_') ? 'gif' : 'png'}?size=128`
          : null

        return {
          id: discordProfile.id,
          name: discordProfile.global_name || discordProfile.username,
          email: null,
          image,
        }
      },
    }),
  ],
  secret: process.env.NEXTAUTH_SECRET,
  session: { strategy: 'jwt' },
  callbacks: {
    async session({ session, token }) {
      if (session.user && token.sub) {
        session.user.id = token.sub
      }
      return session
    },
  },
}
