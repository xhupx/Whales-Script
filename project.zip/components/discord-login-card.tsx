'use client'

import { signIn } from 'next-auth/react'
import { Code2, ShieldCheck } from 'lucide-react'

export function DiscordLoginCard() {
  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#080b12] px-5 py-10 text-slate-100">
      <div className="pointer-events-none absolute -right-24 -top-32 size-[26rem] rounded-full bg-indigo-500/10 blur-[120px]" aria-hidden="true" />
      <section aria-labelledby="login-title" className="relative w-full max-w-md rounded-3xl border border-white/[0.09] bg-[#0d121d]/95 p-7 shadow-[0_24px_90px_rgba(0,0,0,0.45)] sm:p-9">
        <div className="mx-auto flex size-14 items-center justify-center rounded-2xl border border-blue-400/20 bg-gradient-to-br from-blue-500/20 to-violet-500/15 text-blue-200">
          <Code2 className="size-7" aria-hidden="true" />
        </div>
        <p className="mt-6 text-center text-[10px] font-semibold uppercase tracking-[0.2em] text-blue-300">Configuration Studio</p>
        <h1 id="login-title" className="mt-2 text-center text-3xl font-semibold tracking-tight text-white">Mr.Scripts</h1>
        <p className="mx-auto mt-3 max-w-xs text-center text-sm leading-6 text-slate-400">Sign in with Discord to access your configuration workspace.</p>
        <button
          type="button"
          onClick={() => void signIn('discord')}
          className="mt-8 inline-flex h-12 w-full items-center justify-center gap-2.5 rounded-xl bg-[#5865F2] px-4 text-sm font-semibold text-white transition hover:bg-[#4f5be0] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8b93ff] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0d121d]"
        >
          <ShieldCheck className="size-4" aria-hidden="true" />
          Login with Discord
        </button>
        <p className="mt-5 text-center text-[11px] leading-5 text-slate-500">Authentication is handled securely by Discord.</p>
      </section>
    </main>
  )
}
